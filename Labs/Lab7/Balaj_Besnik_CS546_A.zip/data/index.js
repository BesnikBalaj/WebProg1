const pokePostsData = require("./posts");
const pokemonData = require("./animals");

module.exports = {
  animals: pokemonData,
  posts: pokePostsData
};
