const noomber = require("./numbers");

module.exports = {
  noomber
};
