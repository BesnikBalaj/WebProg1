const peopleDataJS = require("./people");

module.exports = {
  peopleDataJS
};
